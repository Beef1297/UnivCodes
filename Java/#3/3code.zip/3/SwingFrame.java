import javax.swing.*;
import java.awt.*;

class SwingFrame {
    public static void main(String argv[]) {
	JFrame f = new JFrame("Swing Frame");
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	f.setSize(300,200);
	f.setVisible(true);
   }
}
