import java.awt.*;

class AWTFrame {
    public static void main(String argv[]) {
	Frame f = new Frame("AWT Frame");
	f.setSize(300,200);
	f.setVisible(true);
    }
}
